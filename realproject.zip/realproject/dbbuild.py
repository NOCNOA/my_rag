import os
import re
from dotenv import load_dotenv, find_dotenv
_ = load_dotenv(find_dotenv())
file_paths = []
folder_path = '/root/autodl-tmp/yuguo-24/yjy/realproject/data'
for root, dirs, files in os.walk(folder_path):
    for file in files:
        file_path = os.path.join(root, file)
        file_paths.append(file_path)

from langchain.document_loaders.pdf import PyMuPDFLoader
from langchain.document_loaders.markdown import UnstructuredMarkdownLoader

# 遍历文件路径并把实例化的loader存放在loaders里
loaders = []
for file_path in file_paths:
    file_type = file_path.split('.')[-1]
    if file_type == 'pdf':
        loaders.append(PyMuPDFLoader(file_path))
    elif file_type == 'md':
        loaders.append(UnstructuredMarkdownLoader(file_path))

# 下载文件并存储到text
texts = []
for loader in loaders: texts.extend(loader.load())
for i in range(len(texts)):
    texts[i].page_content=re.sub(r'------------------.*', '', texts[i].page_content)#去掉注释
    
    
from langchain.text_splitter import RecursiveCharacterTextSplitter
# 切分文档
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000, chunk_overlap=300)
split_docs = text_splitter.split_documents(texts)
  
#构建数据库
from myembedding import ZhipuAIEmbeddings
persist_directory = '/root/autodl-tmp/yuguo-24/yjy/realproject/data_base/vector_db/chroma'
embedding = ZhipuAIEmbeddings()
from langchain.vectorstores.chroma import Chroma
vectordb = Chroma.from_documents(
    documents=split_docs,
    embedding=embedding,
    persist_directory=persist_directory  # 允许我们将persist_directory目录保存到磁盘上
)
vectordb.persist()