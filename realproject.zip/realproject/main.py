from RAG.VectorBase import VectorStore
from RAG.utils import ReadFiles
from RAG.LLM import InternLMChat
from RAG.Embeddings import JinaEmbedding
from myembedding import ZhipuAIEmbeddings
from langchain.vectorstores.chroma import Chroma
#准备数据库
embedding = ZhipuAIEmbeddings()#实例化模型
persist_directory = '/root/autodl-tmp/yuguo-24/yjy/realproject/data_base/vector_db/chroma'#chroma存储位置
vectordb = Chroma(
    persist_directory=persist_directory,  # 允许我们将persist_directory目录保存到磁盘上
    embedding_function=embedding
)
question = "回答一下毛泽东《井冈山的斗争》这篇文章的背景?"
docs = vectordb.similarity_search(question,k=1)#读取最匹配的

#准备语言模型
model = InternLMChat(path='/root/autodl-tmp/yuguo-24/yjy/models/Shanghai_AI_Laboratory/internlm2-chat-7b')
content=docs[0].page_content
print(content)
print("----second:\n"+model.chat(question, [], content))