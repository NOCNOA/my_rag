import torch
from modelscope import snapshot_download, AutoModel, AutoTokenizer
import os

model_dir = snapshot_download('Shanghai_AI_Laboratory/internlm2-chat-7b', cache_dir='/root/autodl-tmp/yuguo-24/yjy/realproject/models', revision='master')
#下载语言模型
model_dir = snapshot_download('jinaai/jina-embeddings-v2-base-zh', cache_dir='/root/autodl-tmp/yuguo-24/yjy/realproject/models', revision='master')
#下载embedding模型
