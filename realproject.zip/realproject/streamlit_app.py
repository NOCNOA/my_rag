import streamlit as st
import requests
import json
from RAG.LLM import PROMPT_TEMPLATE
from myembedding import ZhipuAIEmbeddings
from langchain.vectorstores.chroma import Chroma
# 页面配置
st.set_page_config(page_title="智能问答系统", page_icon="🤖")

# 设置正确的 API 地址和端口
API_URL = "http://127.0.0.1:20251"  # 修改为 6006 端口

# 标题
st.title("智能问答系统 🤖")

# 用户输入
prompt = st.text_area("请输入您的问题：", height=100)

#rag
embedding = ZhipuAIEmbeddings()#实例化模型
persist_directory = '/root/autodl-tmp/yuguo-24/yjy/realproject/data_base/vector_db/chroma'#chroma存储位置
vectordb = Chroma(
    persist_directory=persist_directory,  # 允许我们将persist_directory目录保存到磁盘上
    embedding_function=embedding
)

# 发送按钮
if st.button("发送"):
    if prompt:
        try:
            # 显示加载状态
            with st.spinner('正在思考中...'):
                headers = {'Content-Type': 'application/json'}
                docs = vectordb.similarity_search(prompt,k=1)#读取最匹配的
                prompt =  "接下来我会给你提供一段资料，如果你认为有用就利用我给你提供的内容回答我的问题，如果没用就回答你就尽量回答正确的答案./"+"资料：/"+docs[0].page_content+"\n问题:/"+prompt
                data = {"prompt": prompt}
                response = requests.post(url='http://127.0.0.1:20251', headers=headers, data=json.dumps(data))
                
                
                # 显示回答
                if response.status_code == 200:
                    st.write("回答：")
                    st.write(response.json()["response"])
                else:
                    st.info(f"响应状态码: {response.status_code}")
                    st.error(f"获取答案失败: {response.text}")
        except requests.exceptions.ConnectionError:
            st.error("无法连接到后端服务器，请确保服务器正在运行于20251端口")
        except Exception as e:
            st.error(f"发生错误: {str(e)}")
    else:
        st.warning("请输入问题")

